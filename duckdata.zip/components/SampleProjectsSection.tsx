
import React from 'react';
import { SAMPLE_PROJECTS } from '../constants';

const SampleProjectsSection: React.FC = () => {
  return (
    <section id="sample-projects" className="py-20 sm:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold text-white sm:text-5xl">Sample Projects</h2>
        </div>
        <div className="mt-16 max-w-2xl mx-auto">
          <ul className="space-y-4">
            {SAMPLE_PROJECTS.map((project, index) => (
              <li key={index} className="flex items-center text-lg bg-gray-900 p-4 rounded-lg border border-gray-800">
                <svg className="h-6 w-6 text-gray-500 mr-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>{project}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
};

export default SampleProjectsSection;
