
import React from 'react';
import { HOW_IT_WORKS_STEPS } from '../constants';

const HowItWorksSection: React.FC = () => {
  return (
    <section id="how-it-works" className="py-20 sm:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold text-white sm:text-5xl">How It Works</h2>
        </div>
        <div className="mt-16 max-w-2xl mx-auto">
          <ol className="space-y-6">
            {HOW_IT_WORKS_STEPS.map((step, index) => (
              <li key={index} className="flex items-start">
                <span className="flex-shrink-0 flex items-center justify-center h-10 w-10 rounded-full bg-gray-800 text-white font-bold text-lg border border-gray-700">
                  {index + 1}
                </span>
                <p className="ml-5 text-lg text-gray-300 self-center">{step}</p>
              </li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
