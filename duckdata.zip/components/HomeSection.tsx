
import React from 'react';

const HomeSection: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex flex-col justify-center items-center text-center px-4">
      <h1 className="text-6xl md:text-8xl font-black text-white tracking-tighter">
        <span role="img" aria-label="duck" className="mr-4">🦆</span>
        DuckData
      </h1>
      <p className="mt-4 text-xl md:text-2xl text-gray-400 max-w-2xl">
        “Smart. Simple. Custom AI Data on Demand.”
      </p>
      <p className="mt-6 text-lg text-gray-300 max-w-xl">
        We deliver the image and video datasets you need—exactly how you want them.
      </p>
    </section>
  );
};

export default HomeSection;
