
import React from 'react';
import { TESTIMONIALS } from '../constants';

const TestimonialsSection: React.FC = () => {
  return (
    <section id="testimonials" className="py-20 sm:py-28 bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12">
          {TESTIMONIALS.map((testimonial, index) => (
            <figure key={index}>
              <blockquote className="text-xl italic text-white border-l-4 border-gray-500 pl-6">
                <p>"{testimonial.quote}"</p>
              </blockquote>
              <figcaption className="mt-4 text-right text-base text-gray-400">
                — {testimonial.author}
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
