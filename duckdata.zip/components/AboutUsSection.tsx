
import React from 'react';

const AboutUsSection: React.FC = () => {
  return (
    <section id="about" className="py-20 sm:py-28 bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold text-white sm:text-5xl">About DuckData</h2>
          <p className="mt-6 text-lg text-gray-400">
            We’re on a mission to simplify how AI teams get training data. No scraping. No delays. Just clean, custom datasets delivered to your inbox.
          </p>
        </div>
      </div>
    </section>
  );
};

export default AboutUsSection;
