
import React, { useState } from 'react';

const ContactSection: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you'd handle form submission here.
    // For this static example, we'll just show a confirmation.
    if(name && email && message) {
      setSubmitted(true);
    }
  };

  return (
    <section id="contact" className="py-20 sm:py-28">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold text-white sm:text-5xl">Get in Touch</h2>
          <p className="mt-4 text-lg text-gray-400">
            Have a question or a project in mind? Let's talk.
          </p>
        </div>

        <div className="mt-16 grid md:grid-cols-2 gap-12">
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold text-white">Contact Details</h3>
              <p className="mt-2 text-gray-400">Reach out to us directly through any of these channels.</p>
            </div>
            <div className="space-y-4">
              <p className="flex items-center">
                <span className="font-semibold text-white w-24">Email:</span>
                <a href="mailto:contact@web.com" className="text-gray-300 hover:text-white">contact@web.com</a>
              </p>
              <p className="flex items-center">
                <span className="font-semibold text-white w-24">WhatsApp/Phone:</span>
                <span className="text-gray-300">97410XX257</span>
              </p>
            </div>
             <div>
              <h3 className="text-xl font-semibold text-white mt-8">Alternative</h3>
               <p className="mt-2 text-gray-400">Alternatively, use our Google Form for detailed project specifications.</p>
            </div>
          </div>

          <div>
            {submitted ? (
              <div className="bg-gray-800 p-8 rounded-lg text-center border border-green-500">
                <h3 className="text-2xl font-bold text-white">Thank You!</h3>
                <p className="mt-4 text-gray-300">Your message has been received. We'll get back to you shortly.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-300">Name</label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="mt-1 block w-full bg-gray-800 border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-gray-500 focus:border-gray-500"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-300">Email</label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="mt-1 block w-full bg-gray-800 border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-gray-500 focus:border-gray-500"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-300">Message</label>
                  <textarea
                    id="message"
                    name="message"
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                    className="mt-1 block w-full bg-gray-800 border-gray-600 rounded-md shadow-sm py-2 px-3 text-white focus:outline-none focus:ring-gray-500 focus:border-gray-500"
                  ></textarea>
                </div>
                <div>
                  <button
                    type="submit"
                    className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-black bg-white hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black focus:ring-white transition-colors"
                  >
                    Submit
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
