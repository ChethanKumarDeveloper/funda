
import React from 'react';

const PrivacyPolicySection: React.FC = () => {
  return (
    <section id="privacy" className="py-20 sm:py-28 bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-white text-center sm:text-4xl">Privacy Policy</h2>
          <p className="mt-6 text-base text-gray-400 text-center">
            We value your privacy. All data shared with us is used only to fulfill your request and is never sold or shared.
          </p>
        </div>
      </div>
    </section>
  );
};

export default PrivacyPolicySection;
